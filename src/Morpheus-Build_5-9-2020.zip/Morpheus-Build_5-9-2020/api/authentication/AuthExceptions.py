
class OAuthFailedException(Exception):
    pass


class NoSuchServiceException(Exception):
    pass


class InvalidUserException(Exception):
    pass


class ExistingUserException(Exception):
    pass
